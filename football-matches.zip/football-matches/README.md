# Football Matches Viewer (La Liga)

A simple Node.js + Express web app that displays upcoming soccer matches (La Liga) using data from TheSportsDB.

## ✅ Features
- No XAMPP or Apache needed
- Frontend + Backend served from one Express app
- Fully functional out of the box

## 🚀 Setup Instructions

1. **Install Node.js** if not already installed.

2. **Open a terminal** in this project folder and run:
```bash
npm install
node server.js
```

3. **Open your browser** and visit:
```
http://localhost:3000
```

You’ll see a list of upcoming La Liga matches.

## 🔗 API Used
[TheSportsDB - eventsnextleague API](https://www.thesportsdb.com/api/v1/json/1/eventsnextleague.php?id=4335)


